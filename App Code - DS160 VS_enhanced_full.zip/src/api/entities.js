import { base44 } from './base44Client';


export const Application = base44.entities.Application;



// auth sdk:
export const User = base44.auth;