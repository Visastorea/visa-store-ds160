import React from 'react';
import { motion } from 'framer-motion';

const SectionCard = ({ 
  icon, 
  title, 
  subtitle, 
  children, 
  status = 'current',
  className = '' 
}) => {
  const statusStyles = {
    completed: 'border-green-200 bg-green-50/50',
    current: 'border-blue-200 bg-blue-50/30',
    pending: 'border-gray-200 bg-white',
    error: 'border-red-200 bg-red-50/50'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={`
        bg-white rounded-2xl shadow-lg border-2 overflow-hidden w-full max-w-none
        ${statusStyles[status]}
        ${className}
      `}
    >
      {/* Header */}
      <div className="p-4 sm:p-6 border-b border-gray-100">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
          <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-500 to-green-500 rounded-xl sm:rounded-2xl flex items-center justify-center text-xl sm:text-2xl shadow-lg flex-shrink-0">
            {icon}
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-xl sm:text-2xl font-bold text-gray-800 mb-1 break-words">
              {title}
            </h2>
            {subtitle && (
              <p className="text-sm sm:text-base text-gray-600 font-medium break-words">
                {subtitle}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 sm:p-6 w-full">
        <div className="w-full max-w-none">
          {children}
        </div>
      </div>
    </motion.div>
  );
};

export default SectionCard;