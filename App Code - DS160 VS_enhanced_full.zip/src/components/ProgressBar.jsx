
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { FORM_SECTIONS } from './form/navigation';
import { CheckCircle, Circle, Loader } from 'lucide-react';

const ProgressBar = ({ application, currentSectionId }) => {
  const navigate = useNavigate();
  const currentStepRef = useRef(null);
  const scrollContainerRef = useRef(null);

  // State for drag-to-scroll functionality
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const maritalStatus = application?.data?.personal?.maritalStatus;
  const showSpouseSection = maritalStatus === 'MARRIED' || maritalStatus === 'LEGALLY_SEPARATED';

  const activeFormSections = useMemo(() => {
    return showSpouseSection 
      ? FORM_SECTIONS 
      : FORM_SECTIONS.filter(s => s.id !== 'spouse');
  }, [showSpouseSection]);
  
  // Local definition of getSectionIndex based on activeFormSections
  const getSectionIndex = (id) => activeFormSections.findIndex(s => s.id === id);

  useEffect(() => {
    if (currentStepRef.current) {
      const scrollContainer = scrollContainerRef.current;
      const stepElement = currentStepRef.current;
      const containerWidth = scrollContainer.offsetWidth;
      const stepLeft = stepElement.offsetLeft;
      const stepWidth = stepElement.offsetWidth;

      const scrollPosition = stepLeft - (containerWidth / 2) + (stepWidth / 2);
      scrollContainer.scrollTo({
        left: scrollPosition,
        behavior: 'smooth'
      });
    }
  }, [currentSectionId, activeFormSections]); // Added activeFormSections to dependencies

  const progress = application?.progress || 0;
  const currentSectionIndex = getSectionIndex(currentSectionId);

  const getStatus = (sectionId) => {
    const sectionIndex = getSectionIndex(sectionId);
    if (application?.data?.[sectionId] && Object.keys(application.data[sectionId]).length > 0) {
      if (sectionIndex < currentSectionIndex) return 'completed';
    }
    if (sectionIndex < currentSectionIndex) return 'completed'; // Also mark as completed if just passed
    if (sectionIndex === currentSectionIndex) return 'current';
    return 'pending';
  };

  const isSectionUnlocked = (sectionId) => {
    const targetIndex = getSectionIndex(sectionId);
    // You can go back to any completed section
    return targetIndex <= currentSectionIndex;
  };

  const handleStepClick = (sectionId) => {
    if (isSectionUnlocked(sectionId) && application?.id) {
      const section = activeFormSections.find(s => s.id === sectionId); // Use activeFormSections
      if (section) {
        navigate(createPageUrl(`${section.page}?appId=${application.id}`));
      }
    }
  };

  // Handlers for drag-to-scroll
  const handleMouseDown = (e) => {
    if (!scrollContainerRef.current) return;
    setIsDragging(true);
    setStartX(e.pageX - scrollContainerRef.current.offsetLeft);
    setScrollLeft(scrollContainerRef.current.scrollLeft);
    scrollContainerRef.current.style.cursor = 'grabbing';
    scrollContainerRef.current.style.userSelect = 'none';
  };

  const handleMouseLeave = () => {
    if (isDragging) {
      setIsDragging(false);
      if (scrollContainerRef.current) {
        scrollContainerRef.current.style.cursor = 'grab';
        scrollContainerRef.current.style.userSelect = 'auto';
      }
    }
  };

  const handleMouseUp = () => {
    if (isDragging) {
      setIsDragging(false);
      if (scrollContainerRef.current) {
        scrollContainerRef.current.style.cursor = 'grab';
        scrollContainerRef.current.style.userSelect = 'auto';
      }
    }
  };

  const handleMouseMove = (e) => {
    if (!isDragging || !scrollContainerRef.current) return;
    e.preventDefault();
    const x = e.pageX - scrollContainerRef.current.offsetLeft;
    const walk = (x - startX) * 1.5; // Multiplier for faster scrolling
    scrollContainerRef.current.scrollLeft = scrollLeft - walk;
  };

  return (
    <div className="w-full bg-white shadow-sm sticky top-0 z-20 border-b border-gray-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-lg font-bold text-gray-800">Progresso do Formulário</h2>
          <span className="text-sm font-semibold text-gray-600">{Math.round(progress)}% Completo</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
          <div
            className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full"
            style={{ width: `${progress}%`, transition: 'width 0.5s ease-in-out' }}
          ></div>
        </div>
        
        <div
          ref={scrollContainerRef}
          className="flex items-center space-x-2 sm:space-x-4 overflow-x-auto pb-2 pt-4 scrollbar-hide md:cursor-grab"
          onMouseDown={handleMouseDown}
          onMouseLeave={handleMouseLeave}
          onMouseUp={handleMouseUp}
          onMouseMove={handleMouseMove}
        >
          {activeFormSections.map((section, index) => { // Use activeFormSections
            const status = getStatus(section.id);
            const isCurrent = status === 'current';
            const isCompleted = status === 'completed';
            const isClickable = isSectionUnlocked(section.id);
            const Icon = section.icon;

            return (
              <React.Fragment key={section.id}>
                <div
                  ref={isCurrent ? currentStepRef : null}
                  onClick={() => handleStepClick(section.id)}
                  className={`flex-shrink-0 flex flex-col items-center justify-center text-center w-24 h-24 p-2 rounded-xl transition-all duration-300 relative ${
                    isClickable ? 'cursor-pointer hover:bg-gray-100' : 'cursor-not-allowed'
                  } ${isCurrent ? 'bg-blue-50 border-2 border-blue-400 shadow-lg' : 'bg-gray-50 border border-gray-200'}`}
                >
                  <div className="absolute -top-1 -left-1">
                    {isCompleted && <CheckCircle className="w-5 h-5 text-white bg-green-500 rounded-full" />}
                    {isCurrent && <Loader className="w-5 h-5 text-white bg-blue-500 rounded-full p-0.5 animate-spin" />}
                  </div>
                  
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${isCurrent ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-500'}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className={`mt-2 text-xs font-semibold ${isCurrent ? 'text-blue-600' : 'text-gray-600'}`}>{section.title}</span>
                </div>
                {index < activeFormSections.length - 1 && ( // Use activeFormSections
                  <div className="text-gray-300 font-light text-2xl pb-6">&gt;</div>
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ProgressBar;
