import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { 
  MessageCircle, 
  X, 
  Send, 
  Bot, 
  User, 
  HelpCircle,
  FileText,
  Clock,
  CheckCircle2
} from 'lucide-react';

const FAQ_RESPONSES = {
  'ds160': 'The DS-160 is the Online Nonimmigrant Visa Application form. It must be completed and submitted online prior to your visa interview at the U.S. Embassy or Consulate.',
  'passport': 'Your passport must be valid for travel to the United States with a validity date at least six months beyond your intended period of stay.',
  'photo': 'You need a digital photo that meets specific requirements: 2x2 inches, color, taken within the last 6 months, with a white background.',
  'interview': 'After submitting your DS-160, you need to schedule a visa interview appointment at the U.S. Embassy or Consulate in your country.',
  'documents': 'Required documents typically include: DS-160 confirmation page, passport, photo, visa fee receipt, and supporting documents for your trip purpose.',
  'fees': 'Visa application fees vary by visa type. Check the current fees on the U.S. Embassy website for your country.'
};

const QUICK_ACTIONS = [
  { text: 'What is DS-160?', key: 'ds160', icon: FileText },
  { text: 'Passport requirements', key: 'passport', icon: HelpCircle },
  { text: 'Photo requirements', key: 'photo', icon: User },
  { text: 'Interview process', key: 'interview', icon: Clock },
];

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'bot',
      content: 'Hi! I\'m here to help you with your DS-160 application. What would you like to know?',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const addMessage = (type, content) => {
    const newMessage = {
      id: Date.now(),
      type,
      content,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const handleQuickAction = (key) => {
    const userMessage = QUICK_ACTIONS.find(action => action.key === key)?.text;
    if (userMessage) {
      addMessage('user', userMessage);
      simulateBotResponse(key);
    }
  };

  const simulateBotResponse = (query) => {
    setIsTyping(true);
    
    setTimeout(() => {
      const response = FAQ_RESPONSES[query] || 
        "I'm sorry, I don't have specific information about that. Please contact the U.S. Embassy for detailed assistance.";
      
      addMessage('bot', response);
      setIsTyping(false);
    }, 1000);
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    addMessage('user', inputValue);
    
    // Simple keyword matching for demo
    const query = inputValue.toLowerCase();
    let responseKey = 'default';
    
    Object.keys(FAQ_RESPONSES).forEach(key => {
      if (query.includes(key)) {
        responseKey = key;
      }
    });

    simulateBotResponse(responseKey);
    setInputValue('');
  };

  return (
    <>
      {/* Chat Toggle Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 2 }}
      >
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="w-14 h-14 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg"
        >
          <AnimatePresence mode="wait">
            {isOpen ? (
              <motion.div
                key="close"
                initial={{ rotate: 180, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 180, opacity: 0 }}
              >
                <X className="w-6 h-6" />
              </motion.div>
            ) : (
              <motion.div
                key="chat"
                initial={{ rotate: -180, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: -180, opacity: 0 }}
              >
                <MessageCircle className="w-6 h-6" />
              </motion.div>
            )}
          </AnimatePresence>
        </Button>
        
        {/* Notification Badge */}
        {!isOpen && (
          <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
            <span className="text-xs text-white font-bold">!</span>
          </div>
        )}
      </motion.div>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.8 }}
            className="fixed bottom-24 right-6 w-80 h-96 z-50"
          >
            <Card className="w-full h-full flex flex-col shadow-2xl">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b bg-blue-600 text-white rounded-t-lg">
                <div className="flex items-center gap-2">
                  <Bot className="w-5 h-5" />
                  <span className="font-semibold">DS-160 Assistant</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-xs">Online</span>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-xs p-3 rounded-lg ${
                        message.type === 'user'
                          ? 'bg-blue-600 text-white ml-4'
                          : 'bg-slate-100 text-slate-800 mr-4'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        {message.type === 'bot' && (
                          <Bot className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        )}
                        <span className="text-sm">{message.content}</span>
                        {message.type === 'user' && (
                          <User className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-slate-100 p-3 rounded-lg mr-4">
                      <div className="flex items-center gap-2">
                        <Bot className="w-4 h-4" />
                        <div className="flex gap-1">
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Actions */}
              {messages.length <= 1 && (
                <div className="p-3 border-t bg-slate-50">
                  <p className="text-xs text-slate-600 mb-2">Quick help:</p>
                  <div className="grid grid-cols-2 gap-2">
                    {QUICK_ACTIONS.map((action) => {
                      const Icon = action.icon;
                      return (
                        <Button
                          key={action.key}
                          variant="outline"
                          size="sm"
                          onClick={() => handleQuickAction(action.key)}
                          className="text-xs h-8"
                        >
                          <Icon className="w-3 h-3 mr-1" />
                          {action.text}
                        </Button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Input */}
              <div className="p-3 border-t">
                <div className="flex gap-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Ask me anything..."
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="text-sm"
                  />
                  <Button 
                    onClick={handleSendMessage}
                    size="sm"
                    disabled={!inputValue.trim()}
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}