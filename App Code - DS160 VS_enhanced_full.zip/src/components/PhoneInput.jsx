
import React from 'react'; // Only React is needed after refactor

const PhoneInput = ({ value, onChange, error, placeholder }) => {
  // Como não temos acesso ao react-phone-input-2, vou implementar uma versão aprimorada
  // com bandeiras usando a API de bandeiras e formatação manual

  // Ensure `value` always has a default structure if not provided or is null/undefined
  const currentPhoneValue = value || { iso2: 'br', dialCode: '55', number: '' };

  // Lista de países com bandeiras e códigos de discagem
  const COUNTRIES = [
    { name: 'Brasil', iso2: 'br', dialCode: '55', flag: '🇧🇷' },
    { name: 'Estados Unidos', iso2: 'us', dialCode: '1', flag: '🇺🇸' },
    { name: 'Argentina', iso2: 'ar', dialCode: '54', flag: '🇦🇷' },
    { name: 'Chile', iso2: 'cl', dialCode: '56', flag: '🇨🇱' },
    { name: 'Colômbia', iso2: 'co', dialCode: '57', flag: '🇨🇴' },
    { name: 'França', iso2: 'fr', dialCode: '33', flag: '🇫🇷' },
    { name: 'Alemanha', iso2: 'de', dialCode: '49', flag: '🇩🇪' },
    { name: 'Reino Unido', iso2: 'gb', dialCode: '44', flag: '🇬🇧' },
    { name: 'Itália', iso2: 'it', dialCode: '39', flag: '🇮🇹' },
    { name: 'Espanha', iso2: 'es', dialCode: '34', flag: '🇪🇸' },
    { name: 'Portugal', iso2: 'pt', dialCode: '351', flag: '🇵🇹' },
    { name: 'Canadá', iso2: 'ca', dialCode: '1', flag: '🇨🇦' },
    { name: 'México', iso2: 'mx', dialCode: '52', flag: '🇲🇽' }
  ];

  // Renamed applyMask to formatPhoneNumber as per outline's usage
  const formatPhoneNumber = (number, dialCode) => {
    // Remove all non-digit characters from the input
    const digits = String(number).replace(/\D/g, ''); 
    
    if (dialCode === '55') { // Brasil
      if (digits.length <= 2) return `(${digits}`;
      if (digits.length <= 6) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
      if (digits.length <= 10) return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
      // For 11 digits (mobile with 9th digit)
      return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7, 11)}`;
    }
    
    if (dialCode === '1') { // EUA/Canadá (North American Numbering Plan)
      if (digits.length <= 3) return `(${digits}`;
      if (digits.length <= 6) return `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
      return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6, 10)}`;
    }
    
    if (dialCode === '44') { // Reino Unido (Example format, varies widely by type)
      if (digits.length <= 4) return digits;
      if (digits.length <= 7) return `${digits.slice(0, 4)} ${digits.slice(4)}`;
      return `${digits.slice(0, 4)} ${digits.slice(4, 7)} ${digits.slice(7, 11)}`;
    }
    
    if (dialCode === '33') { // França (Example format)
      if (digits.length <= 2) return digits;
      if (digits.length <= 4) return `${digits.slice(0, 2)} ${digits.slice(2)}`;
      if (digits.length <= 6) return `${digits.slice(0, 2)} ${digits.slice(2, 4)} ${digits.slice(4)}`;
      if (digits.length <= 8) return `${digits.slice(0, 2)} ${digits.slice(2, 4)} ${digits.slice(4, 6)} ${digits.slice(6)}`;
      return `${digits.slice(0, 2)} ${digits.slice(2, 4)} ${digits.slice(4, 6)} ${digits.slice(6, 8)} ${digits.slice(8, 10)}`;
    }
    
    // Default format for other countries: just return digits (no specific mask)
    return digits;
  };

  return (
    <div className="flex flex-col w-full"> {/* Wrapper div to stack input field and error message vertically */}
      <div className="flex gap-2"> {/* Main flex container for the select and input fields */}
        <select
          value={currentPhoneValue.iso2}
          onChange={(e) => {
            const selectedCountry = COUNTRIES.find(c => c.iso2 === e.target.value);
            if (selectedCountry) { // Ensure a country is found before updating state
              onChange({
                iso2: selectedCountry.iso2,
                dialCode: selectedCountry.dialCode,
                number: '' // Clear the number when the country code changes
              });
            }
          }}
          className="w-40 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
        >
          {COUNTRIES.map(country => (
            <option key={country.iso2} value={country.iso2}>
              {country.flag} +{country.dialCode}
            </option>
          ))}
        </select>
        <input
          type="text" // Use type="text" for more control over inputMode/pattern
          inputMode="numeric" // Triggers numeric keyboard on mobile devices
          pattern="[0-9]*" // Helps with numeric keyboard and input validation hint
          value={currentPhoneValue.number}
          onChange={(e) => {
            const formattedValue = formatPhoneNumber(e.target.value, currentPhoneValue.dialCode);
            onChange({ ...currentPhoneValue, number: formattedValue });
          }}
          className={`flex-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors ${error ? 'border-red-500' : 'border-gray-300'}`}
          placeholder={placeholder || 'Número do telefone'} // Use prop or default placeholder
        />
      </div>
      {error && <p className="text-red-500 text-sm mt-1">{error}</p>} {/* Display error message */}
    </div>
  );
};

export default PhoneInput;
