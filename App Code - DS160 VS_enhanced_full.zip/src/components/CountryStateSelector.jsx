import React from 'react';

const COUNTRIES = [
  'Brasil',
  'Afeganistão', 'África do Sul', 'Albânia', 'Alemanha', 'Andorra', 'Angola', 'Antígua e Barbuda',
  'Arábia Saudita', 'Argélia', 'Argentina', 'Armênia', 'Austrália', 'Áustria', 'Azerbaijão',
  'Bahamas', 'Bahrein', 'Bangladesh', 'Barbados', 'Bélgica', 'Belize', 'Benin', 'Bolívia',
  'Bósnia e Herzegovina', 'Botswana', 'Brunei', 'Bulgária', 'Burkina Faso', 'Burundi',
  'Butão', 'Cabo Verde', 'Camarões', 'Camboja', 'Canadá', 'Catar', 'Cazaquistão', 'Chade',
  'Chile', 'China', 'Chipre', 'Colômbia', 'Comores', 'Congo', 'Coreia do Norte', 'Coreia do Sul',
  'Costa do Marfim', 'Costa Rica', 'Croácia', 'Cuba', 'Dinamarca', 'Djibuti', 'Dominica',
  'Egito', 'El Salvador', 'Emirados Árabes Unidos', 'Equador', 'Eritreia', 'Eslováquia',
  'Eslovênia', 'Espanha', 'Estados Unidos', 'Estônia', 'Etiópia', 'Fiji', 'Filipinas',
  'Finlândia', 'França', 'Gabão', 'Gâmbia', 'Gana', 'Geórgia', 'Granada', 'Grécia',
  'Guatemala', 'Guiana', 'Guiné', 'Guiné-Bissau', 'Guiné Equatorial', 'Haiti', 'Honduras',
  'Hungria', 'Iêmen', 'Ilhas Marshall', 'Ilhas Salomão', 'Índia', 'Indonésia', 'Irã', 'Iraque',
  'Irlanda', 'Islândia', 'Israel', 'Itália', 'Jamaica', 'Japão', 'Jordânia', 'Kuwait',
  'Laos', 'Lesoto', 'Letônia', 'Líbano', 'Libéria', 'Líbia', 'Liechtenstein', 'Lituânia',
  'Luxemburgo', 'Macedônia do Norte', 'Madagascar', 'Malásia', 'Malauí', 'Maldivas', 'Mali',
  'Malta', 'Marrocos', 'Maurício', 'Mauritânia', 'México', 'Mianmar', 'Micronésia', 'Moçambique',
  'Moldávia', 'Mônaco', 'Mongólia', 'Montenegro', 'Namíbia', 'Nauru', 'Nepal', 'Nicarágua',
  'Níger', 'Nigéria', 'Noruega', 'Nova Zelândia', 'Omã', 'Países Baixos', 'Palau', 'Panamá',
  'Papua-Nova Guiné', 'Paquistão', 'Paraguai', 'Peru', 'Polônia', 'Portugal', 'Quênia',
  'Quirguistão', 'Reino Unido', 'República Centro-Africana', 'República Checa', 
  'República Democrática do Congo', 'República Dominicana', 'Romênia', 'Ruanda', 'Rússia',
  'Samoa', 'San Marino', 'Santa Lúcia', 'São Cristóvão e Nevis', 'São Tomé e Príncipe',
  'São Vicente e Granadinas', 'Seicheles', 'Senegal', 'Serra Leoa', 'Sérvia', 'Singapura',
  'Síria', 'Somália', 'Sri Lanka', 'Suazilândia', 'Sudão', 'Sudão do Sul', 'Suécia', 'Suíça',
  'Suriname', 'Tailândia', 'Tajiquistão', 'Tanzânia', 'Timor-Leste', 'Togo', 'Tonga',
  'Trinidad e Tobago', 'Tunísia', 'Turcomenistão', 'Turquia', 'Tuvalu', 'Ucrânia', 'Uganda',
  'Uruguai', 'Uzbequistão', 'Vanuatu', 'Vaticano', 'Venezuela', 'Vietnã', 'Zâmbia', 'Zimbábue'
];

const BRAZILIAN_STATES = [
  { code: 'AC', name: 'Acre' },
  { code: 'AL', name: 'Alagoas' },
  { code: 'AP', name: 'Amapá' },
  { code: 'AM', name: 'Amazonas' },
  { code: 'BA', name: 'Bahia' },
  { code: 'CE', name: 'Ceará' },
  { code: 'DF', name: 'Distrito Federal' },
  { code: 'ES', name: 'Espírito Santo' },
  { code: 'GO', name: 'Goiás' },
  { code: 'MA', name: 'Maranhão' },
  { code: 'MT', name: 'Mato Grosso' },
  { code: 'MS', name: 'Mato Grosso do Sul' },
  { code: 'MG', name: 'Minas Gerais' },
  { code: 'PA', name: 'Pará' },
  { code: 'PB', name: 'Paraíba' },
  { code: 'PR', name: 'Paraná' },
  { code: 'PE', name: 'Pernambuco' },
  { code: 'PI', name: 'Piauí' },
  { code: 'RJ', name: 'Rio de Janeiro' },
  { code: 'RN', name: 'Rio Grande do Norte' },
  { code: 'RS', name: 'Rio Grande do Sul' },
  { code: 'RO', name: 'Rondônia' },
  { code: 'RR', name: 'Roraima' },
  { code: 'SC', name: 'Santa Catarina' },
  { code: 'SP', name: 'São Paulo' },
  { code: 'SE', name: 'Sergipe' },
  { code: 'TO', name: 'Tocantins' }
];

const CountryStateSelector = ({ 
  selectedCountry, 
  selectedState, 
  selectedCity, 
  onCountryChange, 
  onStateChange, 
  onCityChange,
  error 
}) => {
  return (
    <div className="space-y-4">
      {/* País */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          🌍 País de nascimento
        </label>
        <select
          value={selectedCountry}
          onChange={(e) => onCountryChange(e.target.value)}
          className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
            error?.country ? 'border-red-500' : 'border-gray-300'
          }`}
        >
          <option value="">Selecione o país...</option>
          {COUNTRIES.map(country => (
            <option key={country} value={country}>{country}</option>
          ))}
        </select>
        {error?.country && (
          <p className="text-red-500 text-sm mt-1">{error.country}</p>
        )}
      </div>

      {/* Estado (apenas se Brasil estiver selecionado) */}
      {selectedCountry === 'Brasil' && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            📍 Estado
          </label>
          <select
            value={selectedState}
            onChange={(e) => onStateChange(e.target.value)}
            className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
              error?.state ? 'border-red-500' : 'border-gray-300'
            }`}
          >
            <option value="">Selecione o estado...</option>
            {BRAZILIAN_STATES.map(state => (
              <option key={state.code} value={state.code}>{state.name}</option>
            ))}
          </select>
          {error?.state && (
            <p className="text-red-500 text-sm mt-1">{error.state}</p>
          )}
        </div>
      )}

      {/* Cidade */}
      {(selectedCountry === 'Brasil' ? selectedState : selectedCountry) && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            🏙️ Cidade de nascimento
          </label>
          <input
            type="text"
            value={selectedCity}
            onChange={(e) => onCityChange(e.target.value)}
            className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
              error?.city ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder={selectedCountry === 'Brasil' ? 'São Paulo' : 'Nome da cidade'}
          />
          {error?.city && (
            <p className="text-red-500 text-sm mt-1">{error.city}</p>
          )}
        </div>
      )}
    </div>
  );
};

export default CountryStateSelector;