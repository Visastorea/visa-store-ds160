
import React, { useState, useEffect, useCallback } from 'react';
import { Application } from '@/api/entities';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, ArrowRight, Save, CheckCircle2, Flag } from 'lucide-react';
import { FORM_SECTIONS, getSectionIndex } from '@/components/form/navigation';
import { Skeleton } from '@/components/ui/skeleton';

export default function FormWrapper({ sectionId, children }) {
  const navigate = useNavigate();
  const location = useLocation();
  
  const [application, setApplication] = useState(null);
  const [formData, setFormData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const appId = new URLSearchParams(location.search).get('appId');
  const currentSectionIndex = getSectionIndex(sectionId);

  const calculateProgress = useCallback(() => {
    if (!formData) return 0;
    const filledSections = FORM_SECTIONS.slice(0, -1).filter(section => {
      return formData[section.id] && Object.values(formData[section.id]).some(v => v);
    }).length;
    return Math.round((filledSections / (FORM_SECTIONS.length - 1)) * 100);
  }, [formData]);

  const loadApplication = useCallback(async () => {
    if (!appId) {
      navigate(createPageUrl("Landing"));
      return;
    }
    setIsLoading(true);
    try {
      const app = await Application.get(appId);
      setApplication(app);
      setFormData(app.data);
    } catch (error) {
      console.error("Failed to load application", error);
      navigate(createPageUrl("Dashboard"));
    }
    setIsLoading(false);
  }, [appId, navigate]);

  useEffect(() => {
    loadApplication();
  }, [loadApplication]);

  const saveProgress = useCallback(async () => {
    if (!application) return;
    setIsSaving(true);
    try {
      const progress = calculateProgress();
      const updatedApp = {
        data: formData,
        progress,
        current_section: sectionId,
        last_activity: new Date().toISOString()
      };
      await Application.update(application.id, updatedApp);
      setApplication(prev => ({ ...prev, ...updatedApp }));
    } catch (error) {
      console.error("Failed to save progress", error);
    }
    setIsSaving(false);
  }, [application, formData, sectionId, calculateProgress]);

  const handleNext = async () => {
    await saveProgress();
    if (currentSectionIndex < FORM_SECTIONS.length - 1) {
      const nextSection = FORM_SECTIONS[currentSectionIndex + 1];
      navigate(createPageUrl(`${nextSection.page}?appId=${appId}`));
    }
  };

  const handlePrev = () => {
    if (currentSectionIndex > 0) {
      const prevSection = FORM_SECTIONS[currentSectionIndex - 1];
      navigate(createPageUrl(`${prevSection.page}?appId=${appId}`));
    }
  };

  const handleSubmit = async () => {
    await saveProgress();
    await Application.update(appId, { status: 'submitted', progress: 100 });
    navigate(createPageUrl('Export?appId=' + appId));
  };
  
  if (isLoading || !formData) {
    return (
      <div className="p-8">
        <Skeleton className="h-16 w-1/2 mb-4" />
        <Skeleton className="h-8 w-1/3 mb-8" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const childrenWithProps = React.cloneElement(children, {
    data: formData[sectionId] || {},
    onChange: (sectionData) => setFormData(prev => ({...prev, [sectionId]: sectionData})),
    formData,
  });
  
  const currentSection = FORM_SECTIONS[currentSectionIndex];

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-10 p-4">
         <div className="max-w-5xl mx-auto">
            <h1 className="text-xl font-bold text-slate-900">{currentSection.title}</h1>
            <p className="text-sm text-slate-500 font-medium">Application ID: {appId}</p>
            <Progress value={calculateProgress()} className="mt-2 h-2" />
         </div>
      </header>
      
      <main className="max-w-5xl mx-auto p-6">
        <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
          <div className="p-8">{childrenWithProps}</div>

          <div className="border-t border-slate-200 bg-slate-50 p-6">
            <div className="flex justify-between items-center">
              <Button variant="outline" onClick={handlePrev} disabled={currentSectionIndex === 0}>
                <ArrowLeft className="w-4 h-4 mr-2" /> Previous
              </Button>
              <div className="flex gap-3">
                <Button variant="outline" onClick={saveProgress} disabled={isSaving}>
                  <Save className="w-4 h-4 mr-2" /> {isSaving ? "Saving..." : "Save"}
                </Button>
                {currentSection.id === 'review' ? (
                  <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
                    <CheckCircle2 className="w-4 h-4 mr-2" /> Submit
                  </Button>
                ) : (
                  <Button onClick={handleNext}>
                    Next <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
