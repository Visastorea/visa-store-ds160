
import { User, Globe, Plane, Users, Landmark, Home, Shield, Briefcase, FileText, BadgeCheck, Flag, BookUser, Heart, List } from 'lucide-react';

export const FORM_SECTIONS = [
  { id: "personal", title: "Pessoal 1", page: "Section1Personal", icon: User },
  { id: "nationality", title: "Pessoal 2", page: "Section2Nationality", icon: Flag },
  { id: "travel", title: "Viagem", page: "Section3Travel", icon: Plane },
  { id: "travelCompanions", title: "Acompanhantes", page: "Section4TravelCompanions", icon: Users },
  { id: "usHistory", title: "Histórico EUA", page: "Section5USHistory", icon: Landmark },
  { id: "addressPhone", title: "Endereço", page: "Section6AddressPhone", icon: Home },
  { id: "passport", title: "Passaporte", page: "Section7Passport", icon: BookUser },
  { id: "family", title: "Família", page: "Section9Family", icon: Users },
  { id: "spouse", title: "Cônjuge", page: "Section9aSpouse", icon: Heart },
  { id: "workEducation", title: "Trabalho/Educação", page: "Section10WorkEducation", icon: Briefcase },
  { id: "additionalInfo", title: "Info Adicionais", page: "Section11aAdditionalInfo", icon: List },
  { id: "security", title: "Segurança", page: "Section11Security", icon: Shield },
  { id: "review", title: "Revisão", page: "Review", icon: BadgeCheck }
];

export const getSectionIndex = (id) => FORM_SECTIONS.findIndex(s => s.id === id);
