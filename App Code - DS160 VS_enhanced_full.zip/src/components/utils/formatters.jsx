export const formatNames = (name) => {
  if (!name) return '';
  
  // Lista de palavras que não devem ser capitalizadas (preposições e artigos)
  const smallWords = ['de', 'da', 'do', 'dos', 'das', 'e', 'a', 'o', 'as', 'os'];
  
  return name
    .toLowerCase()
    .split(' ')
    .map((word, index) => {
      // Primeira palavra sempre é capitalizada
      if (index === 0 || !smallWords.includes(word)) {
        return word.charAt(0).toUpperCase() + word.slice(1);
      }
      return word;
    })
    .join(' ');
};

export const formatCityState = (text) => {
  return formatNames(text);
};

export const formatCPF = (value) => {
  const numbers = value.replace(/\D/g, '');
  return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
};