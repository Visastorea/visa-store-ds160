
import { Application } from '@/api/entities';

// Helper to calculate progress based on filled sections
const calculateProgress = (data) => {
  if (!data) return 0;
  // All sections that count towards progress, excluding 'review'
  const sections = ['personal', 'nationality', 'travel', 'travelCompanions', 'usHistory', 'addressPhone', 'passport', 'usContact', 'family', 'workEducation', 'security'];
  const completedSections = sections.filter(sectionId => {
    const sectionData = data[sectionId];
    // A section is considered complete if it exists and has at least one truthy value.
    return sectionData && Object.values(sectionData).some(value => {
      if (value === null || value === undefined) return false;
      if (typeof value === 'string') return value.trim().length > 0;
      if (Array.isArray(value)) return value.length > 0;
      return !!value;
    });
  });
  return Math.round((completedSections.length / sections.length) * 100);
};

/**
 * Fetches the entire application object from the server.
 * @param {string} appId The ID of the application to load.
 * @returns {Promise<object>} The application object.
 */
export const loadApplication = async (appId) => {
  if (!appId || appId === 'null' || appId === 'undefined' || appId === '-') {
    console.error("Invalid appId provided to loadApplication:", appId);
    throw new Error("Invalid application ID");
  }

  try {
    const application = await Application.get(appId);
    
    if (!application) {
      console.error("No application found with ID:", appId);
      throw new Error("Application not found");
    }
    
    return application;
  } catch (error) {
    console.error("Error loading application:", error);
    throw error;
  }
};

/**
 * Saves a specific section's data and updates the application's overall state.
 * @param {object} app The current application object.
 * @param {string} sectionId The ID of the section being saved (e.g., 'personal').
 * @param {object} sectionData The data for that specific section.
 * @returns {Promise<object>} The updated application object.
 */
export const saveSectionData = async (app, sectionId, sectionData) => {
  if (!app || !app.id) throw new Error("A valid application object is required.");

  const updatedData = {
    ...app.data,
    [sectionId]: sectionData,
  };

  const progress = calculateProgress(updatedData);

  const payload = {
    data: updatedData,
    progress,
    current_section: sectionId,
    last_activity: new Date().toISOString(),
  };

  await Application.update(app.id, payload);

  // Return the updated application state to avoid another fetch
  return { ...app, ...payload };
};
