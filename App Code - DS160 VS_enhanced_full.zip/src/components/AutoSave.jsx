import React, { useEffect, useState, useRef } from 'react';
import { Check, Loader2, AlertCircle } from 'lucide-react';
import { saveSectionData } from './storage';

const AutoSave = ({ 
  application, 
  sectionId, 
  formData, 
  onApplicationUpdate,
  debounceMs = 2000 // Wait 2 seconds after last change before saving
}) => {
  const [saveStatus, setSaveStatus] = useState('idle'); // 'idle', 'saving', 'saved', 'error'
  const [lastSaveTime, setLastSaveTime] = useState(null);
  const timeoutRef = useRef(null);
  const lastFormDataRef = useRef(null);

  useEffect(() => {
    // Clear existing timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    // Don't auto-save if no data or application
    if (!application || !formData || !sectionId) {
      return;
    }

    // Check if form data actually changed
    const currentDataString = JSON.stringify(formData);
    const lastDataString = lastFormDataRef.current;
    
    if (currentDataString === lastDataString) {
      return; // No changes, don't save
    }

    // Set up new timeout for auto-save
    timeoutRef.current = setTimeout(async () => {
      setSaveStatus('saving');
      
      try {
        const updatedApp = await saveSectionData(application, sectionId, formData);
        
        // Update parent component with new application data
        if (onApplicationUpdate) {
          onApplicationUpdate(updatedApp);
        }
        
        setSaveStatus('saved');
        setLastSaveTime(new Date());
        lastFormDataRef.current = currentDataString;

        // Clear "saved" status after 3 seconds
        setTimeout(() => {
          setSaveStatus('idle');
        }, 3000);

      } catch (error) {
        console.error('Auto-save failed:', error);
        setSaveStatus('error');
        
        // Clear error status after 5 seconds
        setTimeout(() => {
          setSaveStatus('idle');
        }, 5000);
      }
    }, debounceMs);

    // Cleanup timeout on unmount or dependency change
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [application, sectionId, formData, debounceMs, onApplicationUpdate]);

  // Don't render anything if idle
  if (saveStatus === 'idle') {
    return null;
  }

  const statusConfig = {
    saving: {
      icon: <Loader2 className="w-4 h-4 animate-spin" />,
      text: 'Salvando...',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-700',
      borderColor: 'border-blue-200'
    },
    saved: {
      icon: <Check className="w-4 h-4" />,
      text: 'Salvo!',
      bgColor: 'bg-green-50',
      textColor: 'text-green-700',
      borderColor: 'border-green-200'
    },
    error: {
      icon: <AlertCircle className="w-4 h-4" />,
      text: 'Erro ao salvar',
      bgColor: 'bg-red-50',
      textColor: 'text-red-700',
      borderColor: 'border-red-200'
    }
  };

  const config = statusConfig[saveStatus];

  return (
    <div className={`
      fixed top-4 right-4 z-50 
      flex items-center gap-2 
      px-3 py-2 rounded-lg shadow-lg border
      ${config.bgColor} ${config.textColor} ${config.borderColor}
      transition-all duration-300 ease-in-out
      animate-in slide-in-from-right-2
    `}>
      {config.icon}
      <span className="text-sm font-medium">{config.text}</span>
      {saveStatus === 'saved' && lastSaveTime && (
        <span className="text-xs opacity-75 ml-1">
          {lastSaveTime.toLocaleTimeString('pt-BR', { 
            hour: '2-digit', 
            minute: '2-digit' 
          })}
        </span>
      )}
    </div>
  );
};

export default AutoSave;