import React, { useState, useEffect } from 'react';
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Calendar as CalendarIcon } from "lucide-react";
import { format, parse, isValid } from 'date-fns';

const DateInput = ({ label, value, onChange, error, minDate, maxDate, required = false, calendarTrigger = 'icon-only' }) => {
  const [displayValue, setDisplayValue] = useState('');
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);

  // Formata o valor YYYY-MM-DD para DD/MM/YYYY ao carregar
  useEffect(() => {
    if (value && isValid(parse(value, 'yyyy-MM-dd', new Date()))) {
      const date = parse(value, 'yyyy-MM-dd', new Date());
      setDisplayValue(format(date, 'dd/MM/yyyy'));
    } else {
      setDisplayValue('');
    }
  }, [value]);

  const handleInputChange = (e) => {
    let input = e.target.value.replace(/\D/g, '');
    input = input.substring(0, 8);

    let maskedValue = input;
    if (input.length > 4) {
      maskedValue = `${input.slice(0, 2)}/${input.slice(2, 4)}/${input.slice(4)}`;
    } else if (input.length > 2) {
      maskedValue = `${input.slice(0, 2)}/${input.slice(2)}`;
    }
    
    setDisplayValue(maskedValue);

    if (maskedValue.length === 10) {
      const parsedDate = parse(maskedValue, 'dd/MM/yyyy', new Date());
      if (isValid(parsedDate)) {
        onChange(format(parsedDate, 'yyyy-MM-dd'));
      }
    }
  };

  const handleDateSelect = (date) => {
    if (date) {
      onChange(format(date, 'yyyy-MM-dd'));
    }
    setIsCalendarOpen(false);
  };
  
  const handleInputClick = () => {
    if (calendarTrigger !== 'icon-only') {
      setIsCalendarOpen(true);
    }
  };

  // Função para converter minDate/maxDate para objetos Date se necessário
  const convertToDate = (dateValue) => {
    if (!dateValue) return undefined;
    
    // Se já é um objeto Date, retorna diretamente
    if (dateValue instanceof Date) {
      return dateValue;
    }
    
    // Se é uma string, tenta fazer o parse
    if (typeof dateValue === 'string') {
      const parsedDate = parse(dateValue, 'yyyy-MM-dd', new Date());
      return isValid(parsedDate) ? parsedDate : undefined;
    }
    
    return undefined;
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <div className="relative">
        <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
          <input
            type="text"
            placeholder="dd/mm/aaaa"
            value={displayValue}
            onChange={handleInputChange}
            onClick={handleInputClick}
            className={`w-full px-4 py-3 pr-10 border rounded-lg focus:ring-2 focus:ring-blue-500 ${error ? 'border-red-500' : 'border-gray-300'}`}
            required={required}
          />
          <PopoverTrigger asChild>
            <Button
              variant={"ghost"}
              className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 p-0 text-gray-500 hover:text-gray-800"
              onClick={() => setIsCalendarOpen(!isCalendarOpen)}
            >
              <CalendarIcon className="h-5 w-5" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={value ? parse(value, 'yyyy-MM-dd', new Date()) : undefined}
              onSelect={handleDateSelect}
              initialFocus
              fromDate={convertToDate(minDate)}
              toDate={convertToDate(maxDate)}
            />
          </PopoverContent>
        </Popover>
      </div>
      {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
    </div>
  );
};

export default DateInput;