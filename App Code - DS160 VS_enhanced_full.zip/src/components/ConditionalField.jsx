import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const ConditionalField = ({
  question,
  value,
  onValueChange,
  children,
  QuestionComponent = 'label'
}) => {
  return (
    <div className="mb-6 p-4 border border-gray-200 rounded-lg bg-gray-50/50">
      <QuestionComponent className="block text-sm font-medium text-gray-700 mb-2">
        {question}
      </QuestionComponent>
      <div className="flex items-center gap-4 mb-4">
        <button
          type="button"
          onClick={() => onValueChange(true)}
          className={`px-6 py-2 border rounded-lg transition-all text-sm font-medium ${
            value === true
              ? 'border-blue-500 bg-blue-100 text-blue-700'
              : 'border-gray-300 hover:border-gray-400'
          }`}
        >
          Sim
        </button>
        <button
          type="button"
          onClick={() => onValueChange(false)}
          className={`px-6 py-2 border rounded-lg transition-all text-sm font-medium ${
            value === false
              ? 'border-blue-500 bg-blue-100 text-blue-700'
              : 'border-gray-300 hover:border-gray-400'
          }`}
        >
          Não
        </button>
      </div>
      
      <AnimatePresence>
        {value === true && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="pt-4 border-t border-gray-200">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ConditionalField;