import React from 'react';

const CurrencyInput = ({ value, onChange, placeholder = "0,00" }) => {
  const formatCurrency = (value) => {
    // Remove tudo que não é dígito
    const digits = value.replace(/\D/g, '');
    
    if (!digits) return '';
    
    // Converte para número e divide por 100 para ter os centavos
    const number = parseInt(digits) / 100;
    
    // Formata como moeda brasileira
    return new Intl.NumberFormat('pt-BR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(number);
  };

  const handleChange = (e) => {
    const formatted = formatCurrency(e.target.value);
    onChange(formatted);
  };

  return (
    <div className="relative">
      <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 font-medium">
        R$
      </span>
      <input
        type="text"
        value={value || ''}
        onChange={handleChange}
        placeholder={placeholder}
        className="form-input pl-10"
      />
    </div>
  );
};

export default CurrencyInput;