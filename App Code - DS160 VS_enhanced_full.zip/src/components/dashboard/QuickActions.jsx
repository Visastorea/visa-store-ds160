import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, BookOpen, HelpCircle, Loader2 } from "lucide-react";

const actions = [
  {
    id: "new-ds160",
    title: "Iniciar Novo DS-160",
    description: "Começar uma nova solicitação de visto",
    icon: Plus,
    color: "bg-slate-800 hover:bg-slate-700",
    isAction: true,
  },
  {
    id: "view-guidelines",
    title: "Ver Orientações", 
    description: "Leia as diretrizes para completar o DS-160",
    icon: BookOpen,
    color: "bg-blue-600",
    isAction: false,
  },
  {
    id: "get-help",
    title: "Obter Ajuda",
    description: "Acesse suporte e perguntas frequentes",
    icon: HelpCircle, 
    color: "bg-green-600",
    isAction: false,
  }
];

export default function QuickActions({ onStartNewApplication, isCreating }) {
  return (
    <Card className="mb-8 border border-slate-200 shadow-lg">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-slate-900">
          Ações Rápidas
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {actions.map((action, index) => {
            const Icon = action.icon;
            
            return (
              <motion.div
                key={action.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Button
                  variant="outline"
                  className={`w-full h-full p-6 flex flex-col items-center gap-3 border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-all duration-200 text-left ${!action.isAction ? 'opacity-60 cursor-not-allowed' : ''}`}
                  onClick={action.isAction && action.id === 'new-ds160' ? onStartNewApplication : undefined}
                  disabled={!action.isAction || (isCreating && action.id === 'new-ds160')}
                >
                  <div className="text-center">
                    <div className={`w-12 h-12 rounded-xl ${action.color} ${action.isAction ? action.color.replace(/bg-([a-z]+)-(\d+)/, 'hover:bg-$1-700') : ''} flex items-center justify-center shadow-lg mx-auto mb-3 transition-colors`}>
                      {isCreating && action.id === 'new-ds160' ? 
                       <Loader2 className="w-6 h-6 text-white animate-spin" /> : 
                       <Icon className="w-6 h-6 text-white" />}
                    </div>
                    <h3 className="font-bold text-slate-900 mb-1">{action.title}</h3>
                    <p className="text-sm text-slate-500 whitespace-normal">{action.description}</p>
                  </div>
                </Button>
              </motion.div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}