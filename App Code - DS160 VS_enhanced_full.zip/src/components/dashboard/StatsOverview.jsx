import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Clock, CheckCircle2, Send } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const statsConfig = [
  {
    title: "Total de Aplicações",
    key: "total",
    icon: FileText,
    color: "from-slate-600 to-slate-800",
    bgColor: "bg-slate-100"
  },
  {
    title: "Em Rascunho", 
    key: "draft",
    icon: Clock,
    color: "from-amber-500 to-amber-600",
    bgColor: "bg-amber-100"
  },
  {
    title: "Concluídas",
    key: "completed", 
    icon: CheckCircle2,
    color: "from-blue-500 to-blue-600",
    bgColor: "bg-blue-100"
  },
  {
    title: "Enviadas",
    key: "submitted",
    icon: Send,
    color: "from-green-500 to-green-600", 
    bgColor: "bg-green-100"
  }
];

export default function StatsOverview({ stats, isLoading }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statsConfig.map((stat, index) => {
        const Icon = stat.icon;
        
        return (
          <motion.div
            key={stat.key}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="relative overflow-hidden border border-slate-200 hover:border-slate-300 transition-colors">
              <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${stat.color} opacity-5 rounded-full transform translate-x-8 -translate-y-8`} />
              
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-semibold text-slate-600 uppercase tracking-wider">
                    {stat.title}
                  </CardTitle>
                  <div className={`p-2 rounded-xl ${stat.bgColor}`}>
                    <Icon className={`w-5 h-5 bg-gradient-to-br ${stat.color} bg-clip-text text-transparent`} />
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                {isLoading ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <div className="text-3xl font-bold text-slate-900">
                    {stats[stat.key]}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}