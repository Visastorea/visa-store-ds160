
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { FileText, Clock, Eye, Edit3, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Application } from "@/api/entities";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const statusConfig = {
  draft: {
    color: "bg-amber-100 text-amber-800 border-amber-200",
    icon: Edit3,
    label: "Rascunho"
  },
  completed: {
    color: "bg-blue-100 text-blue-800 border-blue-200", 
    icon: Eye,
    label: "Concluída"
  },
  submitted: {
    color: "bg-green-100 text-green-800 border-green-200",
    icon: FileText,
    label: "Enviada"
  }
};

export default function ApplicationCard({ application, onUpdate, onContinue }) {
  const statusInfo = statusConfig[application.status] || {
    color: "bg-gray-100 text-gray-800 border-gray-200",
    icon: FileText,
    label: "Desconhecido"
  };
  const StatusIcon = statusInfo.icon;

  const handleContinue = () => {
    const isValidId = application && application.id && String(application.id).trim() !== '' && String(application.id) !== '-';

    if (isValidId) {
      onContinue(application);
    } else {
      console.error("No valid application ID found for continue action", application);
      alert("Erro: O ID desta aplicação parece estar corrompido.");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="border border-slate-200 hover:border-slate-300 hover:shadow-lg transition-all duration-200">
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center">
                <StatusIcon className="w-6 h-6 text-slate-600" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-lg">
                  Aplicação DS-160
                </h3>
                <p className="text-sm text-slate-500 font-medium">
                  Criada em {application.created_date ? format(new Date(application.created_date), "d 'de' MMMM 'de' yyyy", { locale: ptBR }) : 'N/A'}
                </p>
              </div>
            </div>
            <Badge className={`${statusInfo.color} border font-semibold px-3 py-1`}>
              {statusInfo.label}
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-semibold text-slate-700">Progresso</span>
              <span className="text-sm font-bold text-slate-900">{application.progress || 0}%</span>
            </div>
            <Progress value={application.progress || 0} className="h-2 bg-slate-200" />
          </div>

          {application.data?.personal?.fullName && (
            <div className="flex items-center gap-2 text-sm">
              <span className="text-slate-500 font-medium">Requerente:</span>
              <span className="font-semibold text-slate-900">
                {application.data.personal.fullName}
              </span>
            </div>
          )}

          <div className="flex items-center gap-2 text-sm">
            <Clock className="w-4 h-4 text-slate-400" />
            <span className="text-slate-500 font-medium">Última atualização:</span>
            <span className="font-semibold text-slate-700">
              {application.updated_date ? format(new Date(application.updated_date), "d 'de' MMM 'às' HH:mm", { locale: ptBR }) : 'N/A'}
            </span>
          </div>

          <div className="flex gap-2 pt-2">
            <Button 
              onClick={handleContinue}
              variant="outline" 
              className="w-full font-semibold border-slate-300 hover:bg-slate-100"
            >
              <Edit3 className="w-4 h-4 mr-2" />
              Continuar
            </Button>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="outline"
                  className="text-red-600 border-red-200 hover:bg-red-50 font-semibold"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Tem certeza que deseja excluir?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Esta ação não pode ser desfeita. Isso excluirá permanentemente a aplicação e removerá todos os dados associados a ela.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction
                    className="bg-red-600 hover:bg-red-700"
                    onClick={async () => {
                      try {
                        await Application.delete(application.id);
                        onUpdate();
                      } catch (error) {
                        console.error("Failed to delete application:", error);
                        // Você pode adicionar um alerta de erro customizado aqui no futuro
                      }
                    }}
                  >
                    Excluir
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
