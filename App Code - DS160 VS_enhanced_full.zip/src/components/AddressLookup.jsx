import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Search, MapPin, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function AddressLookup({ address, onAddressChange }) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const formatCEP = (value) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{5})(\d{3})/, '$1-$2');
  };

  const lookupCEP = async (cep) => {
    if (!cep || cep.length < 8) return;
    
    setIsLoading(true);
    setError('');
    
    try {
      const cleanCEP = cep.replace(/\D/g, '');
      const response = await fetch(`https://viacep.com.br/ws/${cleanCEP}/json/`);
      const data = await response.json();
      
      if (data.erro) {
        setError('CEP não encontrado');
        return;
      }
      
      onAddressChange({
        ...address,
        cep: formatCEP(cleanCEP),
        street: data.logradouro || '',
        neighborhood: data.bairro || '',
        city: data.localidade || '',
        state: data.uf || ''
      });
      
    } catch (err) {
      setError('Erro ao buscar CEP');
      console.error('CEP lookup error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCEPChange = (value) => {
    const formatted = formatCEP(value);
    onAddressChange({ ...address, cep: formatted });
    
    if (value.replace(/\D/g, '').length === 8) {
      lookupCEP(value);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-4">
        <MapPin className="w-5 h-5 text-blue-600" />
        <h3 className="text-lg font-semibold text-slate-800">Address Information</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="cep">CEP</Label>
          <div className="relative">
            <Input
              id="cep"
              value={address.cep || ''}
              onChange={(e) => handleCEPChange(e.target.value)}
              placeholder="00000-000"
              maxLength={9}
              className="pr-10"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
              ) : (
                <Search className="w-4 h-4 text-slate-400" />
              )}
            </div>
          </div>
          <AnimatePresence>
            {error && (
              <motion.p
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="text-sm text-red-600"
              >
                {error}
              </motion.p>
            )}
          </AnimatePresence>
        </div>

        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="street">Street Address</Label>
          <Input
            id="street"
            value={address.street || ''}
            onChange={(e) => onAddressChange({ ...address, street: e.target.value })}
            placeholder="Enter street address"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="space-y-2">
          <Label htmlFor="number">Number</Label>
          <Input
            id="number"
            value={address.number || ''}
            onChange={(e) => onAddressChange({ ...address, number: e.target.value })}
            placeholder="123"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="complement">Complement</Label>
          <Input
            id="complement"
            value={address.complement || ''}
            onChange={(e) => onAddressChange({ ...address, complement: e.target.value })}
            placeholder="Apt 101"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="neighborhood">Neighborhood</Label>
          <Input
            id="neighborhood"
            value={address.neighborhood || ''}
            onChange={(e) => onAddressChange({ ...address, neighborhood: e.target.value })}
            placeholder="Neighborhood"
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="city">City</Label>
          <Input
            id="city"
            value={address.city || ''}
            onChange={(e) => onAddressChange({ ...address, city: e.target.value })}
            placeholder="City"
            disabled={isLoading}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="state">State</Label>
          <Input
            id="state"
            value={address.state || ''}
            onChange={(e) => onAddressChange({ ...address, state: e.target.value })}
            placeholder="SP"
            disabled={isLoading}
          />
        </div>
      </div>
    </div>
  );
}