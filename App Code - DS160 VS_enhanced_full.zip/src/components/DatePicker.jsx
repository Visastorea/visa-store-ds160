import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function DatePicker({ 
  label, 
  value, 
  onChange, 
  placeholder = "Select date",
  required = false,
  minDate,
  maxDate,
  disabled = false,
  id
}) {
  const [open, setOpen] = useState(false);

  const handleDateSelect = (date) => {
    if (date) {
      onChange(format(date, 'yyyy-MM-dd'));
      setOpen(false);
    }
  };

  const handleInputChange = (inputValue) => {
    // Allow manual typing with Brazilian format dd/mm/yyyy
    const cleanValue = inputValue.replace(/\D/g, '');
    let formatted = cleanValue;
    
    if (cleanValue.length >= 3) {
      formatted = cleanValue.replace(/(\d{2})(\d{2})(\d{4})/, '$1/$2/$3');
    } else if (cleanValue.length >= 3) {
      formatted = cleanValue.replace(/(\d{2})(\d{2})/, '$1/$2');
    }
    
    if (formatted.length === 10) {
      // Convert dd/mm/yyyy to yyyy-mm-dd
      const [day, month, year] = formatted.split('/');
      if (day && month && year) {
        const isoDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
        onChange(isoDate);
      }
    }
  };

  const displayValue = value ? 
    format(new Date(value), 'dd/MM/yyyy', { locale: ptBR }) : '';

  return (
    <div className="space-y-2">
      <Label htmlFor={id}>
        {label} {required && <span className="text-red-500">*</span>}
      </Label>
      
      <div className="flex gap-2">
        <Input
          id={id}
          value={displayValue}
          onChange={(e) => handleInputChange(e.target.value)}
          placeholder="DD/MM/YYYY"
          disabled={disabled}
          className="flex-1"
        />
        
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              disabled={disabled}
              className="px-3"
            >
              <CalendarIcon className="w-4 h-4" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="end">
            <Calendar
              mode="single"
              selected={value ? new Date(value) : undefined}
              onSelect={handleDateSelect}
              locale={ptBR}
              fromDate={minDate}
              toDate={maxDate}
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>
    </div>
  );
}