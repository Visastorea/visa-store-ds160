import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Application } from '@/api/entities';
import { createPageUrl } from '@/utils';
import { Loader2, Save, Brain, ShieldCheck, Plane, Briefcase, Users, GraduationCap, RefreshCw, Activity, FileText } from 'lucide-react';

const purposes = [
  { 
    id: 'tourism', 
    icon: Plane, 
    title: 'Turismo/Lazer', 
    desc: 'Férias, passeios, visitar pontos turísticos',
    color: 'from-blue-500 to-cyan-500'
  },
  { 
    id: 'business', 
    icon: Briefcase, 
    title: 'Negócios', 
    desc: 'Reuniões, conferências, trabalho temporário',
    color: 'from-purple-500 to-pink-500'
  },
  { 
    id: 'family', 
    icon: Users, 
    title: 'Visita Familiar', 
    desc: 'Visitar parentes ou amigos nos EUA',
    color: 'from-green-500 to-emerald-500'
  },
  { 
    id: 'study', 
    icon: GraduationCap, 
    title: 'Estudos', 
    desc: 'Cursos, intercâmbio, pesquisa',
    color: 'from-amber-500 to-orange-500'
  },
  { 
    id: 'renewal', 
    icon: RefreshCw, 
    title: 'Renovação', 
    desc: 'Já tive visto americano antes',
    color: 'from-indigo-500 to-blue-500'
  },
  { 
    id: 'medical', 
    icon: Activity, 
    title: 'Tratamento Médico', 
    desc: 'Consultas, cirurgias, tratamentos',
    color: 'from-red-500 to-rose-500'
  }
];

const benefits = [
  {
    icon: Save,
    title: 'Progresso Salvo Automaticamente',
    description: 'Pode pausar a qualquer momento! Seu progresso é salvo instantaneamente, para você continuar de onde parou.',
    bgColor: 'bg-purple-50',
    borderColor: 'border-purple-300',
    iconColor: 'text-purple-600',
    iconBg: 'bg-purple-100'
  },
  {
    icon: Brain,
    title: 'Processo Rápido e Inteligente',
    description: 'Nosso sistema se adapta às suas respostas e nossa equipe revisa, corrige e entra em contato para garantir que tudo siga sem erros.',
    bgColor: 'bg-orange-50',
    borderColor: 'border-orange-300',
    iconColor: 'text-orange-600',
    iconBg: 'bg-orange-100'
  },
  {
    icon: ShieldCheck,
    title: '100% Seguro e Confiável',
    description: 'Seus dados são protegidos com criptografia de ponta. Sua privacidade é nossa prioridade máxima.',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-300',
    iconColor: 'text-green-600',
    iconBg: 'bg-green-100'
  }
];

export default function Landing() {
  const [selectedProfile, setSelectedProfile] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [hasExistingApplications, setHasExistingApplications] = useState(false);
  const [isCheckingApplications, setIsCheckingApplications] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    checkExistingApplications();
  }, []);

  const checkExistingApplications = async () => {
    setIsCheckingApplications(true);
    try {
      const applications = await Application.list("-updated_date");
      setHasExistingApplications(applications.length > 0);
    } catch (error) {
      console.error("Failed to check existing applications:", error);
      setHasExistingApplications(false);
    }
    setIsCheckingApplications(false);
  };

  const handleStartApplication = async (purposeProfileId) => {
    if (isCreating) {
      return;
    }
    
    setSelectedProfile(purposeProfileId);
    setIsCreating(true);

    try {
      const applicationData = {
        status: "draft",
        progress: 5,
        data: {
          personal: {},
          nationality: {},
          travel: { purpose: purposeProfileId },
          travelCompanions: {},
          usHistory: {},
          addressPhone: {},
          passport: {},
          usContact: {},
          family: {},
          workEducation: {},
          security: {},
          review: {}
        },
        current_section: 'personal',
        last_activity: new Date().toISOString()
      };
      
      const newApp = await Application.create(applicationData);
      
      if (!newApp || !newApp.id) {
        alert("Erro ao criar aplicação. Nenhum ID foi retornado. Por favor, tente novamente.");
        setIsCreating(false);
        setSelectedProfile('');
        return;
      }

      const appId = String(newApp.id).trim();
      
      if (!appId || appId === '' || appId === 'null' || appId === 'undefined' || appId === '-') {
        alert("Erro ao criar aplicação. ID inválido retornado. Por favor, tente novamente.");
        setIsCreating(false);
        setSelectedProfile('');
        return;
      }

      const navigationUrl = createPageUrl(`PassportUpload?appId=${encodeURIComponent(appId)}`);
      navigate(navigationUrl);
      
    } catch (error) {
      console.error("ERROR in handleStartApplication:", error);
      alert(`Erro ao criar aplicação: ${error.message}`);
      setSelectedProfile('');
    } finally {
      setIsCreating(false);
    }
  };

  const handleGoToDashboard = () => {
    navigate(createPageUrl("Dashboard"));
  };

  if (isCheckingApplications) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600 font-medium">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 sm:mb-16"
        >
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-slate-900 mb-4 sm:mb-6">
            US Visto Americano Simplificado
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl text-slate-600 font-medium max-w-3xl mx-auto">
            Preencha seu DS-160 de forma inteligente e segura.
          </p>
        </motion.div>

        {/* Benefits Cards */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 sm:mb-16"
        >
          {benefits.map((benefit, index) => (
            <motion.div
              key={benefit.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
              className={`${benefit.bgColor} ${benefit.borderColor} border-2 rounded-2xl p-6 sm:p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1`}
            >
              <div className={`${benefit.iconBg} w-16 h-16 rounded-xl flex items-center justify-center mb-4 mx-auto`}>
                <benefit.icon className={`w-8 h-8 ${benefit.iconColor}`} />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-slate-800 mb-3 text-center">
                {benefit.title}
              </h3>
              <p className="text-sm sm:text-base text-slate-600 text-center leading-relaxed">
                {benefit.description}
              </p>
            </motion.div>
          ))}
        </motion.div>

        {/* Existing Applications Alert */}
        {hasExistingApplications && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="mb-10 sm:mb-12"
          >
            <div className="bg-blue-50 border-2 border-blue-300 rounded-2xl p-6 sm:p-8 shadow-lg">
              <div className="flex flex-col items-center text-center">
                <div className="bg-blue-100 w-16 h-16 rounded-xl flex items-center justify-center mb-4">
                  <FileText className="w-8 h-8 text-blue-600" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-800 mb-2">
                  Você já possui aplicações em andamento
                </h2>
                <p className="text-slate-600 mb-6 max-w-2xl">
                  Continue trabalhando em suas aplicações existentes ou inicie uma nova abaixo.
                </p>
                <Button
                  onClick={handleGoToDashboard}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 text-base"
                >
                  <FileText className="w-5 h-5 mr-2" />
                  Ver Minhas Aplicações
                </Button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Purpose Selection */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="bg-white rounded-2xl shadow-xl p-6 sm:p-8 lg:p-10 border border-slate-200"
        >
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-800 mb-8 sm:mb-10 text-center">
            🎯 Escolha o motivo principal da sua viagem:
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {purposes.map((purpose, index) => {
              const Icon = purpose.icon;
              return (
                <motion.button
                  key={purpose.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.7 + index * 0.05 }}
                  className={`relative p-6 rounded-xl border-2 transition-all duration-300 ${
                    selectedProfile === purpose.id && isCreating
                      ? 'border-blue-500 bg-blue-50 shadow-lg scale-105'
                      : 'border-slate-200 hover:border-slate-300 hover:shadow-lg hover:-translate-y-1 bg-white'
                  } ${isCreating ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'}`}
                  onClick={() => !isCreating && handleStartApplication(purpose.id)}
                  disabled={isCreating}
                >
                  {isCreating && selectedProfile === purpose.id && (
                    <div className="absolute inset-0 bg-white/90 flex items-center justify-center rounded-xl z-10">
                      <div className="text-center">
                        <Loader2 className="w-8 h-8 text-blue-600 animate-spin mx-auto mb-2" />
                        <p className="text-sm font-semibold text-blue-700">Criando...</p>
                      </div>
                    </div>
                  )}
                  
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${purpose.color} flex items-center justify-center mb-4 mx-auto shadow-md`}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  
                  <h3 className="font-bold text-lg text-slate-800 mb-2 text-center">
                    {purpose.title}
                  </h3>
                  
                  <p className="text-sm text-slate-600 text-center leading-relaxed">
                    {purpose.desc}
                  </p>
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        {/* Footer Info */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 1 }}
          className="text-center mt-8 sm:mt-12"
        >
          <p className="text-sm sm:text-base text-slate-500">
            Seu progresso será salvo automaticamente a cada etapa.
          </p>
        </motion.div>
      </div>
    </div>
  );
}