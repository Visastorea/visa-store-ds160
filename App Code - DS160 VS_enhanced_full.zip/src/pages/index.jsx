import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Landing from "./Landing";

import Export from "./Export";

import Section1Personal from "./Section1Personal";

import Section2Nationality from "./Section2Nationality";

import Section3Travel from "./Section3Travel";

import Section4TravelCompanions from "./Section4TravelCompanions";

import Section5USHistory from "./Section5USHistory";

import Section6AddressPhone from "./Section6AddressPhone";

import Section7Passport from "./Section7Passport";

import Section9Family from "./Section9Family";

import Section10WorkEducation from "./Section10WorkEducation";

import Section11Security from "./Section11Security";

import PassportUpload from "./PassportUpload";

import Section9aSpouse from "./Section9aSpouse";

import Section11aAdditionalInfo from "./Section11aAdditionalInfo";

import Review from "./Review";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Landing: Landing,
    
    Export: Export,
    
    Section1Personal: Section1Personal,
    
    Section2Nationality: Section2Nationality,
    
    Section3Travel: Section3Travel,
    
    Section4TravelCompanions: Section4TravelCompanions,
    
    Section5USHistory: Section5USHistory,
    
    Section6AddressPhone: Section6AddressPhone,
    
    Section7Passport: Section7Passport,
    
    Section9Family: Section9Family,
    
    Section10WorkEducation: Section10WorkEducation,
    
    Section11Security: Section11Security,
    
    PassportUpload: PassportUpload,
    
    Section9aSpouse: Section9aSpouse,
    
    Section11aAdditionalInfo: Section11aAdditionalInfo,
    
    Review: Review,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Landing" element={<Landing />} />
                
                <Route path="/Export" element={<Export />} />
                
                <Route path="/Section1Personal" element={<Section1Personal />} />
                
                <Route path="/Section2Nationality" element={<Section2Nationality />} />
                
                <Route path="/Section3Travel" element={<Section3Travel />} />
                
                <Route path="/Section4TravelCompanions" element={<Section4TravelCompanions />} />
                
                <Route path="/Section5USHistory" element={<Section5USHistory />} />
                
                <Route path="/Section6AddressPhone" element={<Section6AddressPhone />} />
                
                <Route path="/Section7Passport" element={<Section7Passport />} />
                
                <Route path="/Section9Family" element={<Section9Family />} />
                
                <Route path="/Section10WorkEducation" element={<Section10WorkEducation />} />
                
                <Route path="/Section11Security" element={<Section11Security />} />
                
                <Route path="/PassportUpload" element={<PassportUpload />} />
                
                <Route path="/Section9aSpouse" element={<Section9aSpouse />} />
                
                <Route path="/Section11aAdditionalInfo" element={<Section11aAdditionalInfo />} />
                
                <Route path="/Review" element={<Review />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}