
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { createPageUrl } from '@/utils';
import { loadApplication, saveSectionData } from '@/components/storage';
import { ExtractDataFromUploadedFile, UploadFile } from '@/api/integrations';
import { Loader2, UploadCloud, FileCheck2, AlertCircle, Camera, Lightbulb, Sparkles, ArrowRight, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const purposeLabels = {
  tourism: 'Turismo/Lazer',
  business: 'Negócios',
  family: 'Visita Familiar',
  medical: 'Tratamento Médico',
  study: 'Estudos',
  renewal: 'Renovação'
};

export default function PassportUpload() {
  const navigate = useNavigate();
  const location = useLocation();
  // Keep this appId declaration as it might be used outside this specific useEffect,
  // but the useEffect will now re-extract and validate its own version.
  const appId = new URLSearchParams(location.search).get('appId');

  const [application, setApplication] = useState(null);
  const [file, setFile] = useState(null);
  const [error, setError] = useState('');
  const [uploading, setUploading] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isDragActive, setIsDragActive] = useState(false); // New state for drag-and-drop visual feedback
  const fileInputRef = useRef(null); // Ref for the hidden file input

  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const currentAppId = urlParams.get('appId');

    // If there's no AppId, or it's invalid, silently redirect to the dashboard.
    // This prevents showing an error for a recoverable navigation issue.
    if (!currentAppId || currentAppId === 'null' || currentAppId === 'undefined' || currentAppId.trim() === '' || currentAppId === '-') {
      // Navigate to Dashboard only if we are not already on the landing page path
      if (window.location.pathname !== createPageUrl('Landing')) {
          navigate(createPageUrl("Dashboard"));
      }
      return;
    }
    
    const appId = String(currentAppId).trim();

    const fetchApplication = async () => {
      try {
        const app = await loadApplication(appId);
        setApplication(app);
      } catch (e) {
        console.error("PassportUpload - Failed to load application:", e);
        // If loading fails, also redirect.
        navigate(createPageUrl("Dashboard"));
      } finally {
        setIsLoading(false);
      }
    };
    fetchApplication();
  }, [location.search, navigate]);

  const handleFileProcess = useCallback((selectedFiles) => {
    if (selectedFiles && selectedFiles.length > 0) {
      const acceptedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
      const fileToProcess = selectedFiles[0];

      if (acceptedTypes.includes(fileToProcess.type)) {
        setFile(fileToProcess);
        setError('');
      } else {
        setError('Tipo de arquivo não suportado. Use PNG, JPG ou PDF.');
        setFile(null);
      }
    }
  }, []);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDragIn = (e) => {
    handleDrag(e);
    setIsDragActive(true);
  };

  const handleDragOut = (e) => {
    handleDrag(e);
    setIsDragActive(false);
  };

  const handleDrop = (e) => {
    handleDrag(e);
    setIsDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileProcess(e.dataTransfer.files);
      e.dataTransfer.clearData();
    }
  };

  const openFileDialog = () => {
    fileInputRef.current.click();
  };

  const onFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileProcess(e.target.files);
    }
  };

  const handleContinue = async () => {
    if (!file) return;
    setUploading(true);
    setError('');

    try {
      // Passo 1: Fazer o upload do arquivo para obter a URL
      const { file_url } = await UploadFile({ file });
      if (!file_url) throw new Error("A URL do arquivo não foi retornada pelo upload.");

      // Passo 2: Extrair os dados do arquivo usando a URL
      const json_schema = {
        type: "object",
        properties: {
          surnames: { type: "string" },
          givenNames: { type: "string" },
          passportNumber: { type: "string" },
          countryOfIssuance: { type: "string" },
          nationality: { type: "string" },
          dateOfBirth: { type: "string", format: "date" },
          dateOfIssue: { type: "string", format: "date" },
          dateOfExpiration: { type: "string", format: "date" },
          placeOfBirth: { type: "string" },
          sex: { type: "string", enum: ["M", "F", "X"] }
        },
      };

      const extractionResult = await ExtractDataFromUploadedFile({ file_url, json_schema });

      if (extractionResult.status === 'error' || !extractionResult.output) {
        throw new Error(extractionResult.details || 'Falha ao extrair dados do passaporte.');
      }

      const extractedData = extractionResult.output;

      const updatedData = { ...application.data };

      // Mapeamento dos dados extraídos para o formulário
      // Garante que os campos de país e nacionalidade sejam definidos como Brasil/Brasileira
      // independentemente do resultado da leitura do passaporte.
      updatedData.personal = {
        ...updatedData.personal,
        surnames: extractedData.surnames || updatedData.personal?.surnames,
        givenNames: extractedData.givenNames || updatedData.personal?.givenNames,
        sex: extractedData.sex === 'M' ? 'MALE' : extractedData.sex === 'F' ? 'FEMALE' : updatedData.personal?.sex,
        birthDate: extractedData.dateOfBirth || updatedData.personal?.birthDate,
        birthCity: updatedData.personal?.birthCity,
        birthState: updatedData.personal?.birthState,
        birthCountry: 'Brasil', // << CORREÇÃO: Força o país de nascimento para Brasil
        placeOfBirthRaw: extractedData.placeOfBirth || updatedData.personal?.placeOfBirthRaw
      };

      updatedData.passport = {
        ...updatedData.passport,
        passportNumber: extractedData.passportNumber || updatedData.passport?.passportNumber,
        passportIssuingCountry: 'br', // << CORREÇÃO: Força o país emissor para Brasil (código 'br')
        issuanceDate: extractedData.dateOfIssue || updatedData.passport?.issuanceDate,
        expirationDate: extractedData.dateOfExpiration || updatedData.passport?.expirationDate
      };

      updatedData.nationality = {
          ...updatedData.nationality,
          countryOfOrigin: 'Brasileira' // << CORREÇÃO: Força a nacionalidade para Brasileira
      };

      const updatedApp = await saveSectionData(application, 'passport', updatedData.passport);
      const finalApp = await saveSectionData(updatedApp, 'personal', updatedData.personal);
      await saveSectionData(finalApp, 'nationality', updatedData.nationality);

      navigate(createPageUrl(`Section1Personal?appId=${appId}`));
    } catch (e) {
      console.error(e);
      setError("Não foi possível processar o passaporte. Por favor, verifique a imagem ou pule esta etapa.");
    } finally {
      setUploading(false);
    }
  };

  const handleSkip = () => {
    navigate(createPageUrl(`Section1Personal?appId=${appId}`));
  };

  const handleChangePurpose = () => {
    navigate(createPageUrl("Landing"));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="animate-spin text-blue-600 w-12 h-12" />
      </div>
    );
  }

  const selectedPurpose = application?.data?.travel?.purpose;
  const purposeLabel = selectedPurpose ? purposeLabels[selectedPurpose] || selectedPurpose : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-slate-100 p-4 sm:p-8 flex items-center justify-center">
      <div className="w-full max-w-4xl">
        {/* Indicador de Tipo de Visto Selecionado */}
        {purposeLabel && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="bg-white/80 backdrop-blur-sm border border-blue-200 rounded-2xl p-4 mb-6 shadow-lg"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                  <span className="text-blue-600 font-semibold text-sm">✓</span>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-600">Motivo da viagem selecionado:</p>
                  <p className="font-bold text-slate-800 text-lg">{purposeLabel}</p>
                </div>
              </div>
              <button
                onClick={handleChangePurpose}
                className="px-4 py-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors font-medium text-sm border border-blue-200 hover:border-blue-300"
              >
                Alterar Motivo
              </button>
            </div>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-white border-4 border-blue-200 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Sparkles className="w-8 h-8 text-blue-600" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-800">Vamos começar com seu passaporte!</h1>
            <p className="text-lg text-slate-600 mt-2 max-w-2xl mx-auto">
              Envie uma foto da página de dados do seu passaporte. Isso economiza seu tempo e preenche vários campos automaticamente.
            </p>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Coluna de Dicas */}
          <motion.div
            className="lg:col-span-2 bg-white/60 backdrop-blur-sm border border-slate-200 rounded-2xl p-6"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h3 className="font-bold text-slate-800 text-lg mb-4">Dicas para uma boa foto</h3>
            <ul className="space-y-4 text-slate-700">
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Camera className="w-4 h-4 text-green-700" />
                </div>
                <span>Use uma foto nítida e bem iluminada da página principal do seu passaporte (a que tem sua foto).</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Lightbulb className="w-4 h-4 text-amber-700" />
                </div>
                <span>Evite reflexos (de luzes ou flash) e sombras que possam cobrir as informações.</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <FileCheck2 className="w-4 h-4 text-indigo-700" />
                </div>
                <span>Certifique-se de que todos os quatro cantos do passaporte estejam visíveis na imagem.</span>
              </li>
            </ul>
          </motion.div>

          {/* Coluna de Upload */}
          <motion.div
            className="lg:col-span-3 bg-white border border-slate-200 rounded-2xl p-6 shadow-xl"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <div
              onClick={openFileDialog} // Handles click to open file dialog
              onDrop={handleDrop} // Handles file drop
              onDragEnter={handleDragIn} // Handles drag entering
              onDragLeave={handleDragOut} // Handles drag leaving
              onDragOver={handleDrag} // Handles drag over
              className={`flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-xl cursor-pointer transition-all duration-300
                ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-slate-300 bg-slate-50 hover:bg-slate-100'}`}
            >
              <input
                ref={fileInputRef} // Associates the ref with the input
                type="file"
                onChange={onFileChange} // Handles file selection via click
                accept="image/jpeg,image/png,application/pdf"
                className="hidden" // Hides the actual input element
              />
              {uploading ? (
                <>
                  <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
                  <p className="mt-4 text-lg font-semibold text-blue-700">Analisando passaporte...</p>
                  <p className="text-sm text-slate-500">Isso pode levar alguns segundos.</p>
                </>
              ) : file ? (
                <div className="text-center p-4">
                  <FileCheck2 className="w-12 h-12 text-green-600 mx-auto" />
                  <p className="mt-2 font-semibold text-slate-800 break-all">{file.name}</p>
                  <p className="text-sm text-slate-500">Arquivo pronto para envio!</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={(e) => { e.stopPropagation(); setFile(null); }}
                  >
                    <X className="w-4 h-4 mr-1" /> Remover
                  </Button>
                </div>
              ) : (
                <div className="text-center">
                  <UploadCloud className="w-12 h-12 text-slate-400 mx-auto" />
                  <p className="mt-4 font-semibold text-slate-700">
                    {isDragActive ? 'Solte o arquivo aqui!' : 'Arraste e solte o arquivo ou clique aqui'}
                  </p>
                  <p className="text-sm text-slate-500">PNG, JPG ou PDF</p>
                </div>
              )}
            </div>

            {error && (
              <div className="mt-4 flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <p className="text-sm font-medium">{error}</p>
              </div>
            )}

            <div className="mt-6 flex flex-col sm:flex-row-reverse items-center gap-4">
              <Button
                onClick={handleContinue}
                disabled={!file || uploading}
                className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg hover:shadow-xl transition-all"
              >
                Continuar com o arquivo <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button
                onClick={handleSkip}
                variant="ghost"
                className="w-full sm:w-auto text-slate-600 hover:text-slate-800 hover:bg-slate-100"
              >
                Pular esta etapa
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
