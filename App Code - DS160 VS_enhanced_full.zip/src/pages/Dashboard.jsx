
import React, { useState, useEffect } from "react";
import { Application } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, FileText, Clock, CheckCircle2, AlertCircle, Eye, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { FORM_SECTIONS } from "@/components/form/navigation";

import ApplicationCard from "../components/dashboard/ApplicationCard";
import StatsOverview from "../components/dashboard/StatsOverview";
import QuickActions from "../components/dashboard/QuickActions";

export default function Dashboard() {
  const [applications, setApplications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState("all");
  const navigate = useNavigate();

  useEffect(() => {
    loadApplications();
  }, []);

  const loadApplications = async () => {
    setIsLoading(true);
    try {
      const data = await Application.list("-updated_date");
      setApplications(data);
    } catch (error) {
      console.error("Failed to load applications:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartNewApplication = () => {
    // This function no longer needs to be async or handle data creation.
    // It now simply navigates to the Landing page.
    setIsCreating(true); // Kept for visual feedback on the button while navigating.
    navigate(createPageUrl("Landing"));
  };

  const filteredApplications = applications.filter(app =>
    selectedStatus === "all" || app.status === selectedStatus
  );

  const getStatusStats = () => {
    return {
      total: applications.length,
      draft: applications.filter(app => app.status === "draft").length,
      completed: applications.filter(app => app.status === "completed").length,
      submitted: applications.filter(app => app.status === "submitted").length
    };
  };

  const handleContinueApplication = (app) => {
    const isValidId = app && app.id && String(app.id).trim() !== '' && String(app.id) !== '-';

    if (!isValidId) {
      console.error("Invalid application object passed to continue:", app);
      alert("Erro: Não é possível continuar com uma aplicação com ID inválido.");
      return;
    }
    
    const appId = String(app.id);
    const section = FORM_SECTIONS.find(s => s.id === app.current_section) || FORM_SECTIONS[0];
    const url = createPageUrl(`${section.page}?appId=${appId}`);
    
    navigate(url);
  };

  // Se ainda está carregando, mostra apenas um loading simples sem o layout completo do Dashboard
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-slate-800 mx-auto mb-4"></div>
          <p className="text-slate-600 font-medium">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto p-6 md:p-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">
              Aplicações DS-160
            </h1>
            <p className="text-slate-600 font-medium">
              Gerencie suas solicitações de visto americano com facilidade
            </p>
          </div>
          <Button
            onClick={handleStartNewApplication}
            disabled={isCreating}
            className="bg-slate-800 hover:bg-slate-700 text-white px-6 py-3 text-base font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
          >
            {isCreating ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Plus className="w-5 h-5 mr-2" />}
            Nova Aplicação
          </Button>
        </div>

        {/* Stats Overview */}
        <StatsOverview stats={getStatusStats()} isLoading={isLoading} />

        {/* Quick Actions */}
        <QuickActions onStartNewApplication={handleStartNewApplication} isCreating={isCreating} />

        {/* Applications List */}
        <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
          <div className="p-6 border-b border-slate-200">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <h2 className="text-xl font-bold text-slate-900">
                Suas Aplicações ({filteredApplications.length})
              </h2>
              <div className="flex gap-2">
                {[
                  { key: "all", label: "Todas" },
                  { key: "draft", label: "Rascunho" },
                  { key: "completed", label: "Concluída" },
                  { key: "submitted", label: "Enviada" }
                ].map((status) => (
                  <Button
                    key={status.key}
                    variant={selectedStatus === status.key ? "default" : "outline"}
                    onClick={() => setSelectedStatus(status.key)}
                    className={`capitalize font-semibold rounded-lg ${
                      selectedStatus === status.key
                        ? "bg-slate-800 text-white"
                        : "text-slate-600 border-slate-300 hover:bg-slate-100"
                    }`}
                  >
                    {status.label}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          <div className="p-6">
            <AnimatePresence mode="wait">
              {filteredApplications.length > 0 ? (
                <div className="space-y-4">
                  {filteredApplications.map((application) => (
                    <ApplicationCard
                      key={application.id}
                      application={application}
                      onUpdate={loadApplications}
                      onContinue={handleContinueApplication}
                    />
                  ))}
                </div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center py-12"
                >
                  <FileText className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                  <h3 className="text-xl font-semibold text-slate-700 mb-2">
                    Nenhuma aplicação encontrada
                  </h3>
                  <p className="text-slate-500 mb-6">
                    {selectedStatus === "all"
                      ? "Comece criando sua primeira aplicação DS-160"
                      : `Nenhuma aplicação ${selectedStatus === "draft" ? "em rascunho" : selectedStatus === "completed" ? "concluída" : "enviada"} encontrada`
                    }
                  </p>
                  <Button
                    onClick={handleStartNewApplication}
                    disabled={isCreating}
                    className="bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl"
                  >
                    {isCreating ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Plus className="w-5 h-5 mr-2" />}
                    Criar Nova Aplicação
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
